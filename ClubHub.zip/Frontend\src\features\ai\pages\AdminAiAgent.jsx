import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import io from 'socket.io-client';
import axiosInstance from '../../../api/axiosInstance';
import { useSelector } from 'react-redux';
import '../style/AdminAiAgent.scss';

const AdminAiAgent = () => {
    const { user } = useSelector((state) => state.auth);
    const [events, setEvents] = useState([]);
    const [mode, setMode] = useState('General Chat');
    const [selectedEventId, setSelectedEventId] = useState('');
    const [messages, setMessages] = useState([
        { id: 'initial-msg', role: 'ai', content: 'Hello! I am your AI assistant. How can I help you manage ClubHub today?' }
    ]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    const chatEndRef = useRef(null);
    const socketRef = useRef(null);
    const streamMessageIdRef = useRef('');

    useEffect(() => {
        const socket = io('https://clubhub-4bla.onrender.com');
        socketRef.current = socket;
        
        socket.on('chat_stream', (data) => {
            setIsLoading(false); 
            if (data && data.text) {
                setMessages(prev => prev.map(msg => {
                    if (msg.id === streamMessageIdRef.current) {
                        return { ...msg, content: data.text };
                    }
                    return msg;
                }));
            }
        });

        const fetchEvents = async () => {
            try {
                const endpoint = user?.role === 'president' || user?.isClubMember ? '/events/president/all' : '/events';
                const response = await axiosInstance.get(endpoint);
                setEvents(response.data.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchEvents();

        return () => {
            socket.disconnect();
        };
    }, [user]);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const handleSend = async () => {
        if (!inputValue.trim() || isLoading) return;

        const userMsg = { id: `user-${Date.now()}`, role: 'user', content: inputValue.trim() };
        
        const aiMessageId = `ai-${Date.now()}`;
        streamMessageIdRef.current = aiMessageId;
        
        const newHistory = [...messages, userMsg];
        setMessages([...newHistory, { id: aiMessageId, role: 'ai', content: '' }]);
        setInputValue('');
        setIsLoading(true);

        const historyForApi = newHistory.map(msg => ({
            role: msg.role,
            content: msg.content
        }));

        try {
            const response = await axiosInstance.post('/ai/chat', {
                history: historyForApi,
                mode,
                eventId: mode === 'Event Specific' ? selectedEventId : null,
                socketId: socketRef.current?.id 
            });

            if (response.data && response.data.data) {
                setMessages(prev => prev.map(msg => {
                    if (msg.id === aiMessageId) {
                        return { ...msg, content: response.data.data };
                    }
                    return msg;
                }));
            }
        } catch (error) {
            console.error(error);
            setMessages(prev => {
                const updated = [...prev];
                updated[updated.length - 1].content = 'Error: Failed to process request.';
                return updated;
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="ai-agent-page">
            <div className="agent-header">
                <div className="header-info">
                    <h2><i className="ri-robot-2-line" style={{ color: '#2563eb' }}></i> AI Assistant</h2>
                    <p>Automate emails and event updates using AI.</p>
                </div>
                <div className="agent-controls">
                    <select value={mode} onChange={(e) => setMode(e.target.value)}>
                        <option value="General Chat">General Chat</option>
                        <option value="Event Specific">Event Specific</option>
                    </select>
                    {mode === 'Event Specific' && (
                        <select value={selectedEventId} onChange={(e) => setSelectedEventId(e.target.value)}>
                            <option value="">Select Event...</option>
                            {events.filter(ev => ev.status !== 'Completed').map(ev => <option key={ev._id} value={ev._id}>{ev.title}</option>)}
                        </select>
                    )}
                </div>
            </div>

            <div className="chat-window">
                {messages.map((msg) => (
                    <div key={msg.id} className={`message ${msg.role} ${msg.content === '' ? 'hidden' : ''}`}>
                        {msg.role === 'ai' ? (
                            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                {msg.content}
                            </ReactMarkdown>
                        ) : (
                            msg.content
                        )}
                    </div>
                ))}
                
                {isLoading && (
                    <div key="loading-indicator" className="message ai typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                )}
                
                <div ref={chatEndRef} />
            </div>

            <div className="chat-input-area">
                <input 
                    type="text" 
                    placeholder="E.g., Send an email to everyone about the new guidelines..." 
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    disabled={isLoading || (mode === 'Event Specific' && !selectedEventId)}
                />
                <button onClick={handleSend} disabled={isLoading || (mode === 'Event Specific' && !selectedEventId)}>
                    <i className="ri-send-plane-fill"></i> Send
                </button>
            </div>
        </div>
    );
};

export default AdminAiAgent;
